ALTER TABLE "documents" ADD COLUMN "user_id" integer NOT NULL;--> statement-breakpoint
ALTER TABLE "suggestions" ADD COLUMN "user_id" integer NOT NULL;